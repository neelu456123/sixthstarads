import React from 'react';

import { motion } from "motion/react";

import ContactUsForm from '../Form/bannercontactform';


export default function ContactUsbanner() {
  return (
    <div>
      
       
      <div className='row main-row'>
      <div className='col-sm contact-first-column'>
        <div className='cntact-main'><ContactUsForm/></div>
      
      </div>
    
      </div>


      
      
    </div>
  )
}
