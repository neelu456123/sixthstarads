import React from 'react'
import LoanCalculator from '../../components/eminew'

export default function index() {
  return (
    <div>

<LoanCalculator/>
    </div>
  )
}
