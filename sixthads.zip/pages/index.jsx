import React from 'react'

export default function index() {
  return (
    <div>
      <h1>hi</h1>
    </div>
  )
}
